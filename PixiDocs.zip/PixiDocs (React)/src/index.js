import React from "react";
import ReactDOM from "react-dom/client";
import PixiDocs from ".src/pages/PixiDocs";
import "./index.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <PixiDocs />
  </React.StrictMode>
);
