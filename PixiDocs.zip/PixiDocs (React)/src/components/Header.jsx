import React from "react";
import { FileText } from "lucide-react";

const Header = () => {
  return (
    <header className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
            <FileText className="text-white" size={24} />
          </div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            PixiDocs
          </h1>
        </div>
        <div className="text-sm text-gray-600">
          AI-Powered Document & Image Tools
        </div>
      </div>
    </header>
  );
};

export default Header;
