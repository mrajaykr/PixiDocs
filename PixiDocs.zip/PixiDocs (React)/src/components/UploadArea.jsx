import React from "react";
import { Upload } from "lucide-react";

const UploadArea = ({ onFileSelect, onDrop, accept, multiple }) => {
  return (
    <div
      onDrop={onDrop}
      onDragOver={(e) => e.preventDefault()}
      onClick={() => document.getElementById("fileInput").click()}
      className="border-3 border-dashed border-indigo-300 rounded-xl p-12 text-center bg-indigo-50 hover:bg-indigo-100 transition-colors cursor-pointer"
    >
      <Upload className="mx-auto mb-4 text-indigo-600" size={48} />

      <p className="text-lg font-medium text-gray-800 mb-2">
        Drop your files here or click to browse
      </p>

      <p className="text-sm text-gray-600">
        {multiple ? "Select multiple files" : "Select a single file"}
      </p>

      <input
        id="fileInput"
        type="file"
        accept={accept}
        multiple={multiple}
        onChange={onFileSelect}
        className="hidden"
      />
    </div>
  );
};

export default UploadArea;
