import React from "react";
import { Loader2, Wand2 } from "lucide-react";

const ProcessButton = ({ onClick, processing }) => {
  return (
    <button
      onClick={onClick}
      disabled={processing}
      className="mt-6 w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-xl font-semibold text-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
    >
      {processing ? (
        <>
          <Loader2 className="animate-spin mr-2" size={20} />
          Processing...
        </>
      ) : (
        <>
          <Wand2 className="mr-2" size={20} />
          Process Files
        </>
      )}
    </button>
  );
};

export default ProcessButton;
