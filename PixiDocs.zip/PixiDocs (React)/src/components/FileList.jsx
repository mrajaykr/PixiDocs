import React from "react";
import { FileText, X, GripVertical } from "lucide-react";

const FileList = ({ 
  files, 
  isMergeTool, 
  onRemove, 
  onDragStart, 
  onDragOver, 
  onDragEnd, 
  draggedIndex 
}) => {

  return (
    <div className="mt-6">
      <h3 className="font-semibold text-gray-800 mb-3">
        {isMergeTool
          ? `Files to Merge (${files.length}) - Drag to Reorder`
          : `Selected Files (${files.length})`}
      </h3>

      {isMergeTool ? (
        // MERGE VIEW
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">

          {files.map((file, index) => (
            <div
              key={index}
              draggable
              onDragStart={() => onDragStart(index)}
              onDragOver={(e) => onDragOver(e, index)}
              onDragEnd={onDragEnd}
              className={`relative bg-white rounded-xl shadow-lg p-6 cursor-move transition-all duration-200 ${
                draggedIndex === index ? "opacity-50 scale-95" : "hover:shadow-xl"
              }`}
            >
              <div className="absolute top-3 left-3 text-gray-400">
                <GripVertical size={22} />
              </div>

              <div className="w-full h-48 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-lg mb-4 flex items-center justify-center overflow-hidden">
                {file.type.startsWith("image/") ? (
                  <img
                    src={URL.createObjectURL(file)}
                    alt={file.name}
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <FileText className="text-indigo-600" size={64} />
                )}
              </div>

              <p className="font-medium text-gray-800 truncate text-center">{file.name}</p>
              <p className="text-sm text-gray-500 text-center">
                {(file.size / 1024).toFixed(1)} KB
              </p>

              <button
                onClick={() => onRemove(index)}
                className="absolute bottom-3 right-3 bg-red-500 text-white p-2 rounded-full hover:bg-red-600"
              >
                <X size={16} />
              </button>
            </div>
          ))}
        </div>

      ) : (
        // SIMPLE LIST
        <div className="space-y-2">
          {files.map((file, index) => (
            <div
              key={index}
              className="flex items-center justify-between bg-gray-50 p-3 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                <FileText className="text-gray-600" size={20} />
                <span className="text-gray-800">{file.name}</span>
                <span className="text-sm text-gray-500">
                  ({(file.size / 1024).toFixed(1)} KB)
                </span>
              </div>

              <button
                onClick={() => onRemove(index)}
                className="text-red-500 hover:text-red-700"
              >
                <X size={20} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FileList;
