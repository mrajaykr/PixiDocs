import React from "react";

const ToolCard = ({ tool, setActiveTool }) => {
  return (
    <button
      onClick={() => setActiveTool(tool.id)}
      className="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group"
    >
      <div className="flex flex-col items-center text-center">
        <div className="w-16 h-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mb-3 group-hover:from-indigo-200 group-hover:to-purple-200 transition-colors">
          <tool.icon className="text-indigo-600" size={28} />
        </div>
        <h4 className="font-semibold text-gray-800">{tool.name}</h4>
      </div>
    </button>
  );
};

export default ToolCard;
