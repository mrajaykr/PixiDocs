import React from "react";

const DownloadModal = ({
  show,
  fileName,
  setFileName,
  onCancel,
  onConfirm
}) => {
  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
        
        <h3 className="text-xl font-bold text-gray-800 mb-4">Name Your File</h3>

        <p className="text-gray-600 mb-4">Enter a custom name for your download:</p>

        <input
          type="text"
          value={fileName}
          onChange={(e) => setFileName(e.target.value)}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 mb-4"
          placeholder="Enter file name..."
          autoFocus
          onKeyDown={(e) => e.key === "Enter" && onConfirm()}
        />

        <div className="flex space-x-3">
          
          <button
            onClick={onCancel}
            className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
          >
            Cancel
          </button>

          <button
            onClick={onConfirm}
            className="flex-1 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 font-semibold"
          >
            Download
          </button>

        </div>

      </div>
    </div>
  );
};

export default DownloadModal;
