import React from "react";

const Footer = () => {
  return (
    <footer className="bg-white border-t mt-16 py-6">
      <div className="max-w-7xl mx-auto px-4 text-center text-gray-600">
        © 2024 PixiDocs. All rights reserved. Powered by AI.
      </div>
    </footer>
  );
};

export default Footer;
