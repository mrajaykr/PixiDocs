import React, { useState } from "react";
import UploadArea from "../../components/UploadArea";
import FileList from "../../components/FileList";
import ProcessButton from "../../components/ProcessButton";
import DownloadModal from "../../components/DownloadModal";
import { Check } from "lucide-react";

const ResizeImage = ({ goHome }) => {
  const [files, setFiles] = useState([]);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);

  const [options, setOptions] = useState({
    width: 800,
    height: 600,
  });

  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [pendingDownload, setPendingDownload] = useState(null);
  const [downloadName, setDownloadName] = useState("");

  const handleSelect = (e) => {
    setFiles(Array.from(e.target.files));
    setResult(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setFiles(Array.from(e.dataTransfer.files));
    setResult(null);
  };

  const resizeOne = (file) =>
    new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = options.width;
        canvas.height = options.height;

        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, options.width, options.height);

        canvas.toBlob((blob) => {
          resolve({
            name: `resized_${file.name}`,
            size: blob.size,
            blob,
          });
        });
      };
      img.src = URL.createObjectURL(file);
    });

  const processResize = async () => {
    if (!files.length) {
      alert("Select at least one image.");
      return;
    }

    setProcessing(true);

    const results = await Promise.all(files.map(resizeOne));

    setResult({
      message: "Images resized successfully",
      files: results,
    });

    setProcessing(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">

      <button onClick={goHome} className="mb-6 text-indigo-600 font-medium">
        ← Back to Tools
      </button>

      <div className="bg-white p-8 rounded-xl shadow mb-6">
        <h2 className="text-3xl font-bold">Resize Image</h2>

        <div className="mt-4 flex gap-4">
          <div>
            <label>Width (px)</label>
            <input
              type="number"
              value={options.width}
              onChange={(e) =>
                setOptions({ ...options, width: parseInt(e.target.value) })
              }
              className="border p-2 rounded w-24"
            />
          </div>

          <div>
            <label>Height (px)</label>
            <input
              type="number"
              value={options.height}
              onChange={(e) =>
                setOptions({ ...options, height: parseInt(e.target.value) })
              }
              className="border p-2 rounded w-24"
            />
          </div>
        </div>
      </div>

      <UploadArea
        accept="image/*"
        multiple={true}
        onFileSelect={handleSelect}
        onDrop={handleDrop}
      />

      {files.length > 0 && (
        <>
          <FileList files={files} isMergeTool={false} onRemove={() => {}} />
          <ProcessButton processing={processing} onClick={processResize} />
        </>
      )}

      {result && (
        <div className="mt-6 bg-green-50 border border-green-300 p-6 rounded-xl">
          <div className="flex items-center mb-4">
            <Check className="text-green-600 mr-2" />
            <h3>{result.message}</h3>
          </div>

          {result.files.map((file, i) => (
            <div
              key={i}
              className="flex justify-between bg-white p-3 rounded mb-2"
            >
              <div>
                <p>{file.name}</p>
                <p className="text-gray-500 text-sm">
                  {(file.size / 1024).toFixed(1)} KB
                </p>
              </div>
              <button
                className="px-4 py-2 bg-green-600 text-white rounded"
                onClick={() =>
                  setShowDownloadModal(true) ||
                  setPendingDownload({ blob: file.blob, name: file.name }) ||
                  setDownloadName(file.name)
                }
              >
                Download
              </button>
            </div>
          ))}
        </div>
      )}

      <DownloadModal
        show={showDownloadModal}
        fileName={downloadName}
        setFileName={setDownloadName}
        onCancel={() => setShowDownloadModal(false)}
        onConfirm={() => {
          const { blob, name } = pendingDownload;
          const url = URL.createObjectURL(blob);

          const a = document.createElement("a");
          a.href = url;
          a.download = downloadName || name;
          document.body.appendChild(a);
          a.click();
          a.remove();

          URL.revokeObjectURL(url);
          setShowDownloadModal(false);
        }}
      />
    </div>
  );
};

export default ResizeImage;
