import React, { useState } from "react";
import UploadArea from "../../components/UploadArea";
import FileList from "../../components/FileList";
import ProcessButton from "../../components/ProcessButton";
import DownloadModal from "../../components/DownloadModal";
import { Check } from "lucide-react";

const MergeImages = ({ goHome }) => {
  const [files, setFiles] = useState([]);
  const [mergeDirection, setMergeDirection] = useState("horizontal");
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);

  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [pendingDownload, setPendingDownload] = useState(null);
  const [downloadName, setDownloadName] = useState("");

  const handleSelect = (e) => {
    setFiles(Array.from(e.target.files));
    setResult(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setFiles(Array.from(e.dataTransfer.files));
    setResult(null);
  };

  const removeFile = (i) => {
    setFiles((prev) => prev.filter((_, idx) => idx !== i));
  };

  const triggerDownload = (blob, name) => {
    setPendingDownload({ blob, name });
    setDownloadName(name);
    setShowDownloadModal(true);
  };

  const confirmDownload = () => {
    const { blob, name } = pendingDownload;
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = downloadName || name;
    document.body.appendChild(a);
    a.click();
    a.remove();

    URL.revokeObjectURL(url);

    setPendingDownload(null);
    setShowDownloadModal(false);
  };

  const mergeImages = async () => {
    if (files.length < 2) {
      alert("Minimum 2 images required to merge.");
      return;
    }

    setProcessing(true);

    try {
      const loadImage = (file) =>
        new Promise((resolve, reject) => {
          const img = new Image();
          img.onload = () => resolve(img);
          img.onerror = reject;
          img.src = URL.createObjectURL(file);
        });

      const images = await Promise.all(files.map(loadImage));

      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");

      if (mergeDirection === "horizontal") {
        canvas.width = images.reduce((sum, img) => sum + img.width, 0);
        canvas.height = Math.max(...images.map((img) => img.height));

        let x = 0;
        images.forEach((img) => {
          ctx.drawImage(img, x, 0);
          x += img.width;
        });
      } else {
        canvas.width = Math.max(...images.map((img) => img.width));
        canvas.height = images.reduce((sum, img) => sum + img.height, 0);

        let y = 0;
        images.forEach((img) => {
          ctx.drawImage(img, 0, y);
          y += img.height;
        });
      }

      const blob = await new Promise((resolve) =>
        canvas.toBlob(resolve, "image/png")
      );

      setResult({
        message: `${files.length} images merged successfully`,
        files: [{ name: "merged.png", size: blob.size, blob }],
      });
    } catch (err) {
      alert("Image merge failed.");
      console.error(err);
    }

    setProcessing(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">

      <button onClick={goHome} className="mb-6 text-indigo-600 font-medium">
        ← Back to Tools
      </button>

      <div className="bg-white p-8 rounded-xl shadow-md mb-6">
        <h2 className="text-3xl font-bold">Merge Images</h2>
        <p className="text-gray-600">Choose merge direction & upload images.</p>

        {files.length > 0 && (
          <div className="mt-4">
            <label className="block mb-2 font-medium">Merge Direction</label>
            <div className="flex gap-4">
              <button
                onClick={() => setMergeDirection("horizontal")}
                className={`px-4 py-2 rounded ${
                  mergeDirection === "horizontal"
                    ? "bg-indigo-600 text-white"
                    : "bg-gray-100"
                }`}
              >
                Horizontal →
              </button>

              <button
                onClick={() => setMergeDirection("vertical")}
                className={`px-4 py-2 rounded ${
                  mergeDirection === "vertical"
                    ? "bg-indigo-600 text-white"
                    : "bg-gray-100"
                }`}
              >
                Vertical ↓
              </button>
            </div>
          </div>
        )}
      </div>

      <UploadArea
        accept="image/*"
        multiple={true}
        onFileSelect={handleSelect}
        onDrop={handleDrop}
      />

      {files.length > 0 && (
        <>
          <FileList files={files} isMergeTool={true} onRemove={removeFile} />
          <ProcessButton processing={processing} onClick={mergeImages} />
        </>
      )}

      {result && (
        <div className="mt-6 p-6 bg-green-50 border border-green-200 rounded-xl">
          <div className="flex items-center mb-4">
            <Check className="text-green-600 mr-2" />
            <h3 className="font-semibold">{result.message}</h3>
          </div>

          {result.files.map((file, i) => (
            <div
              key={i}
              className="flex justify-between bg-white p-3 rounded mb-2"
            >
              <div>
                <p>{file.name}</p>
                <p className="text-gray-500 text-sm">
                  {(file.size / 1024).toFixed(1)} KB
                </p>
              </div>
              <button
                className="px-4 py-2 bg-green-600 text-white rounded"
                onClick={() => triggerDownload(file.blob, file.name)}
              >
                Download
              </button>
            </div>
          ))}
        </div>
      )}

      <DownloadModal
        show={showDownloadModal}
        fileName={downloadName}
        setFileName={setDownloadName}
        onCancel={() => setShowDownloadModal(false)}
        onConfirm={confirmDownload}
      />
    </div>
  );
};

export default MergeImages;
