import React, { useState } from "react";
import UploadArea from "../../components/UploadArea";
import FileList from "../../components/FileList";
import ProcessButton from "../../components/ProcessButton";
import DownloadModal from "../../components/DownloadModal";
import { Check } from "lucide-react";

const CompressImage = ({ goHome }) => {
  const [files, setFiles] = useState([]);
  const [quality, setQuality] = useState(0.7); // 70%
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);

  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [pendingDownload, setPendingDownload] = useState(null);
  const [downloadName, setDownloadName] = useState("");

  const handleSelect = (e) => {
    setFiles(Array.from(e.target.files));
    setResult(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setFiles(Array.from(e.dataTransfer.files));
    setResult(null);
  };

  const compressOne = (file) =>
    new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0);

        canvas.toBlob(
          (blob) => {
            resolve({
              name: `compressed_${file.name}`,
              size: blob.size,
              blob,
            });
          },
          "image/jpeg",
          quality
        );
      };
      img.src = URL.createObjectURL(file);
    });

  const processCompress = async () => {
    if (!files.length) {
      alert("Select image(s) first.");
      return;
    }

    setProcessing(true);

    const compressed = await Promise.all(files.map(compressOne));

    setResult({
      message: "Images compressed successfully",
      files: compressed,
    });

    setProcessing(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">

      <button onClick={goHome} className="mb-6 text-indigo-600 font-medium">
        ← Back to Tools
      </button>

      <div className="bg-white p-8 rounded-xl shadow mb-6">
        <h2 className="text-3xl font-bold">Compress Image</h2>

        <div className="mt-4">
          <label className="font-medium">Quality ({quality * 100}%)</label>
          <input
            type="range"
            min="0.1"
            max="1"
            step="0.05"
            value={quality}
            onChange={(e) => setQuality(parseFloat(e.target.value))}
            className="w-full"
          />
        </div>
      </div>

      <UploadArea
        accept="image/*"
        multiple={true}
        onFileSelect={handleSelect}
        onDrop={handleDrop}
      />

      {files.length > 0 && (
        <>
          <FileList files={files} isMergeTool={false} onRemove={() => {}} />
          <ProcessButton processing={processing} onClick={processCompress} />
        </>
      )}

      {result && (
        <div className="mt-6 bg-green-50 border border-green-300 p-6 rounded-xl">
          <div className="flex items-center mb-4">
            <Check className="text-green-600 mr-2" />
            <h3>{result.message}</h3>
          </div>

          {result.files.map((file, i) => (
            <div
              key={i}
              className="flex justify-between bg-white p-3 rounded mb-2"
            >
              <div>
                <p>{file.name}</p>
                <p className="text-gray-500 text-sm">
                  {(file.size / 1024).toFixed(1)} KB
                </p>
              </div>
              <button
                className="px-4 py-2 bg-green-600 text-white rounded"
                onClick={() =>
                  setShowDownloadModal(true) ||
                  setPendingDownload({ blob: file.blob, name: file.name }) ||
                  setDownloadName(file.name)
                }
              >
                Download
              </button>
            </div>
          ))}
        </div>
      )}

      <DownloadModal
        show={showDownloadModal}
        fileName={downloadName}
        setFileName={setDownloadName}
        onCancel={() => setShowDownloadModal(false)}
        onConfirm={() => {
          const { blob, name } = pendingDownload;
          const url = URL.createObjectURL(blob);

          const a = document.createElement("a");
          a.href = url;
          a.download = downloadName || name;
          document.body.appendChild(a);
          a.click();
          a.remove();

          URL.revokeObjectURL(url);
          setShowDownloadModal(false);
        }}
      />
    </div>
  );
};

export default CompressImage;
