import React, { useState } from "react";
import UploadArea from "../../components/UploadArea";
import FileList from "../../components/FileList";
import ProcessButton from "../../components/ProcessButton";
import DownloadModal from "../../components/DownloadModal";
import { Check } from "lucide-react";

const EnhanceImage = ({ goHome }) => {
  const [files, setFiles] = useState([]);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);

  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [pendingDownload, setPendingDownload] = useState(null);
  const [downloadName, setDownloadName] = useState("");

  const handleSelect = (e) => {
    setFiles(Array.from(e.target.files));
    setResult(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setFiles(Array.from(e.dataTransfer.files));
    setResult(null);
  };

  const removeFile = (i) => {
    setFiles((prev) => prev.filter((_, idx) => idx !== i));
  };

  const enhance = async () => {
    if (!files.length) {
      alert("Select image(s) first.");
      return;
    }

    setProcessing(true);

    await new Promise((r) => setTimeout(r, 1500)); // fake AI delay

    const enhanced = files.map((f) => ({
      name: `enhanced_${f.name}`,
      size: Math.floor(f.size * 1.2),
      originalSize: f.size,
      blob: f,
    }));

    setResult({
      message: `AI Enhanced (${files.length} images) — simulated`,
      files: enhanced,
    });

    setProcessing(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">

      <button onClick={goHome} className="mb-6 text-indigo-600 font-medium">
        ← Back to Tools
      </button>

      <div className="bg-white p-8 rounded-xl shadow mb-6">
        <h2 className="text-3xl font-bold">AI Enhance Image</h2>
        <p className="text-gray-600">Frontend simulation — real AI = backend</p>
      </div>

      <UploadArea
        accept="image/*"
        multiple={true}
        onFileSelect={handleSelect}
        onDrop={handleDrop}
      />

      {files.length > 0 && (
        <>
          <FileList files={files} isMergeTool={false} onRemove={removeFile} />
          <ProcessButton processing={processing} onClick={enhance} />
        </>
      )}

      {result && (
        <div className="mt-6 bg-green-50 border border-green-300 p-6 rounded-xl">
          <div className="flex items-center mb-3">
            <Check className="text-green-600 mr-2" />
            <h3>{result.message}</h3>
          </div>

          {result.files.map((file, i) => (
            <div
              key={i}
              className="flex justify-between bg-white p-3 rounded mb-2"
            >
              <div>
                <p>{file.name}</p>
                <p className="text-sm text-gray-500">
                  {(file.size / 1024).toFixed(1)} KB 
                  <span className="text-green-600 ml-2">
                    (+{((file.size - file.originalSize) / 1024).toFixed(1)} KB)
                  </span>
                </p>
              </div>

              <button
                className="px-4 py-2 bg-green-600 text-white rounded"
                onClick={() =>
                  setShowDownloadModal(true) ||
                  setPendingDownload({ blob: file.blob, name: file.name }) ||
                  setDownloadName(file.name)
                }
              >
                Download
              </button>
            </div>
          ))}

          <div className="mt-2 p-3 bg-blue-50 border border-blue-200 rounded">
            <strong>Note:</strong> This is simulated enhancement. Real model integration = backend.
          </div>
        </div>
      )}

      <DownloadModal
        show={showDownloadModal}
        fileName={downloadName}
        setFileName={setDownloadName}
        onCancel={() => setShowDownloadModal(false)}
        onConfirm={() => {
          const { blob, name } = pendingDownload;
          const url = URL.createObjectURL(blob);

          const a = document.createElement("a");
          a.href = url;
          a.download = downloadName || name;
          document.body.appendChild(a);
          a.click();
          a.remove();

          URL.revokeObjectURL(url);
          setShowDownloadModal(false);
        }}
      />
    </div>
  );
};

export default EnhanceImage;
