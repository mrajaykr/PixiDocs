import React, { useState } from "react";
import UploadArea from "../../components/UploadArea";
import FileList from "../../components/FileList";
import ProcessButton from "../../components/ProcessButton";
import DownloadModal from "../../components/DownloadModal";
import { Check } from "lucide-react";

const CompressPDF = ({ goHome }) => {
  const [file, setFile] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);

  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [downloadName, setDownloadName] = useState("");
  const [pendingDownload, setPendingDownload] = useState(null);

  const handleFileSelect = (e) => {
    const selected = Array.from(e.target.files || []);
    setFile(selected[0] || null);
    setResult(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer.files || []);
    setFile(dropped[0] || null);
    setResult(null);
  };

  const handleRemove = () => {
    setFile(null);
    setResult(null);
  };

  const triggerDownload = (blob, name) => {
    setPendingDownload({ blob, name });
    setDownloadName(name);
    setShowDownloadModal(true);
  };

  const confirmDownload = () => {
    if (!pendingDownload) return;

    const url = URL.createObjectURL(pendingDownload.blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = downloadName || pendingDownload.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setShowDownloadModal(false);
    setPendingDownload(null);
    setDownloadName("");
  };

  const processCompress = async () => {
    if (!file) {
      alert("Pehle ek PDF select karo.");
      return;
    }

    setProcessing(true);
    setResult(null);

    try {
      // 🤷‍♂️ Browser me real PDF compression mushkil hai.
      // Yaha hum sirf simulated size change kar rahe hain.
      const arrayBuffer = await file.arrayBuffer();
      const blob = new Blob([arrayBuffer], { type: "application/pdf" });

      const compressedSize = Math.floor(file.size * 0.7); // Display-only

      setResult({
        message: "PDF compressed (simulated — frontend only)",
        files: [
          {
            name: `compressed_${file.name}`,
            size: compressedSize,
            blob,
          },
        ],
      });
    } catch (err) {
      console.error("Compress error:", err);
      alert("PDF compress mein error aaya.");
    }

    setProcessing(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={goHome}
        className="mb-6 text-indigo-600 hover:text-indigo-800 flex items-center font-medium"
      >
        ← Back to Tools
      </button>

      <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Compress PDF</h2>
        <p className="text-gray-600">
          Simple client-side compression simulation. Real compression ke liye
          backend + Ghostscript chahiye.
        </p>
      </div>

      <UploadArea
        accept=".pdf"
        multiple={false}
        onFileSelect={handleFileSelect}
        onDrop={handleDrop}
      />

      {file && (
        <>
          <FileList
            files={[file]}
            isMergeTool={false}
            onRemove={handleRemove}
          />
          <ProcessButton onClick={processCompress} processing={processing} />
        </>
      )}

      {result && (
        <div className="mt-6 bg-green-50 border-2 border-green-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <Check className="text-green-600 mr-2" size={24} />
            <h3 className="text-lg font-semibold text-green-800">
              {result.message}
            </h3>
          </div>

          {result.files.map((file, i) => (
            <div
              key={i}
              className="flex items-center justify-between bg-white p-3 rounded-lg mb-2"
            >
              <div>
                <div className="text-gray-800">{file.name}</div>
                <div className="text-sm text-gray-500">
                  {(file.size / 1024).toFixed(1)} KB (approx)
                </div>
              </div>
              <button
                onClick={() => triggerDownload(file.blob, file.name)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Download
              </button>
            </div>
          ))}
        </div>
      )}

      <DownloadModal
        show={showDownloadModal}
        fileName={downloadName}
        setFileName={setDownloadName}
        onCancel={() => {
          setShowDownloadModal(false);
          setPendingDownload(null);
          setDownloadName("");
        }}
        onConfirm={confirmDownload}
      />
    </div>
  );
};

export default CompressPDF;
