import React, { useState, useEffect } from "react";
import UploadArea from "../../components/UploadArea";
import FileList from "../../components/FileList";
import ProcessButton from "../../components/ProcessButton";
import DownloadModal from "../../components/DownloadModal";
import { Check } from "lucide-react";

const MergePDF = ({ goHome }) => {
  const [files, setFiles] = useState([]);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [draggedIndex, setDraggedIndex] = useState(null);

  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [downloadName, setDownloadName] = useState("");
  const [pendingDownload, setPendingDownload] = useState(null);

  const [pdfLibLoaded, setPdfLibLoaded] = useState(false);

  // Load pdf-lib from CDN
  useEffect(() => {
    if (window.PDFLib) {
      setPdfLibLoaded(true);
      return;
    }

    const script = document.createElement("script");
    script.src =
      "https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js";
    script.async = true;
    script.onload = () => setPdfLibLoaded(true);
    script.onerror = () => console.error("Failed to load PDF-lib");
    document.head.appendChild(script);
  }, []);

  const handleFileSelect = (e) => {
    const selected = Array.from(e.target.files || []);
    setFiles(selected);
    setResult(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer.files || []);
    setFiles(dropped);
    setResult(null);
  };

  const handleRemove = (index) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const moveFile = (fromIndex, toIndex) => {
    setFiles((prev) => {
      const arr = [...prev];
      const [moved] = arr.splice(fromIndex, 1);
      arr.splice(toIndex, 0, moved);
      return arr;
    });
  };

  const handleDragStart = (index) => setDraggedIndex(index);

  const handleDragOver = (e, index) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === index) return;
    moveFile(draggedIndex, index);
    setDraggedIndex(index);
  };

  const handleDragEnd = () => setDraggedIndex(null);

  const triggerDownload = (blob, name) => {
    setPendingDownload({ blob, name });
    setDownloadName(name);
    setShowDownloadModal(true);
  };

  const confirmDownload = () => {
    if (!pendingDownload) return;

    const url = URL.createObjectURL(pendingDownload.blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = downloadName || pendingDownload.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setShowDownloadModal(false);
    setPendingDownload(null);
    setDownloadName("");
  };

  const processMerge = async () => {
    if (files.length < 2) {
      alert("PDF merge ke liye kam se kam 2 files chahiye.");
      return;
    }
    if (!pdfLibLoaded || !window.PDFLib) {
      alert("PDF library abhi load ho rahi hai. Thoda wait karke dobara try karo.");
      return;
    }

    setProcessing(true);
    setResult(null);

    try {
      const { PDFDocument } = window.PDFLib;
      const mergedPdf = await PDFDocument.create();

      for (const file of files) {
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await PDFDocument.load(arrayBuffer);
        const copiedPages = await mergedPdf.copyPages(
          pdf,
          pdf.getPageIndices()
        );
        copiedPages.forEach((page) => mergedPdf.addPage(page));
      }

      const mergedBytes = await mergedPdf.save();
      const blob = new Blob([mergedBytes], { type: "application/pdf" });

      setResult({
        message: `${files.length} PDFs merged successfully`,
        files: [
          {
            name: "merged.pdf",
            size: blob.size,
            blob,
          },
        ],
      });
    } catch (err) {
      console.error("Merge error:", err);
      alert("PDF merge mein error aaya. Console check karo.");
    }

    setProcessing(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Back */}
      <button
        onClick={() => {
          goHome();
        }}
        className="mb-6 text-indigo-600 hover:text-indigo-800 flex items-center font-medium"
      >
        ← Back to Tools
      </button>

      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Merge PDF</h2>
        <p className="text-gray-600">
          Upload multiple PDFs, drag to reorder, and merge into a single file.
        </p>
      </div>

      {/* Upload */}
      <UploadArea
        accept=".pdf"
        multiple={true}
        onFileSelect={handleFileSelect}
        onDrop={handleDrop}
      />

      {/* Files */}
      {files.length > 0 && (
        <>
          <FileList
            files={files}
            isMergeTool={true}
            onRemove={handleRemove}
            onDragStart={handleDragStart}
            onDragOver={handleDragOver}
            onDragEnd={handleDragEnd}
            draggedIndex={draggedIndex}
          />

          <ProcessButton onClick={processMerge} processing={processing} />
        </>
      )}

      {/* Result */}
      {result && (
        <div className="mt-6 bg-green-50 border-2 border-green-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <Check className="text-green-600 mr-2" size={24} />
            <h3 className="text-lg font-semibold text-green-800">
              {result.message}
            </h3>
          </div>

          {result.files.map((file, i) => (
            <div
              key={i}
              className="flex items-center justify-between bg-white p-3 rounded-lg mb-2"
            >
              <div>
                <div className="text-gray-800">{file.name}</div>
                <div className="text-sm text-gray-500">
                  {(file.size / 1024).toFixed(1)} KB
                </div>
              </div>
              <button
                onClick={() => triggerDownload(file.blob, file.name)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Download
              </button>
            </div>
          ))}
        </div>
      )}

      <DownloadModal
        show={showDownloadModal}
        fileName={downloadName}
        setFileName={setDownloadName}
        onCancel={() => {
          setShowDownloadModal(false);
          setPendingDownload(null);
          setDownloadName("");
        }}
        onConfirm={confirmDownload}
      />
    </div>
  );
};

export default MergePDF;
