import React, { useState, useEffect } from "react";
import UploadArea from "../../components/UploadArea";
import FileList from "../../components/FileList";
import ProcessButton from "../../components/ProcessButton";
import DownloadModal from "../../components/DownloadModal";
import { Check } from "lucide-react";

const SplitPDF = ({ goHome }) => {
  const [file, setFile] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);

  const [splitPages, setSplitPages] = useState({ from: "", to: "" });

  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [downloadName, setDownloadName] = useState("");
  const [pendingDownload, setPendingDownload] = useState(null);

  const [pdfLibLoaded, setPdfLibLoaded] = useState(false);

  useEffect(() => {
    if (window.PDFLib) {
      setPdfLibLoaded(true);
      return;
    }

    const script = document.createElement("script");
    script.src =
      "https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js";
    script.async = true;
    script.onload = () => setPdfLibLoaded(true);
    script.onerror = () => console.error("Failed to load PDF-lib");
    document.head.appendChild(script);
  }, []);

  const handleFileSelect = (e) => {
    const selected = Array.from(e.target.files || []);
    setFile(selected[0] || null);
    setResult(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer.files || []);
    setFile(dropped[0] || null);
    setResult(null);
  };

  const handleRemove = () => {
    setFile(null);
    setResult(null);
  };

  const triggerDownload = (blob, name) => {
    setPendingDownload({ blob, name });
    setDownloadName(name);
    setShowDownloadModal(true);
  };

  const confirmDownload = () => {
    if (!pendingDownload) return;

    const url = URL.createObjectURL(pendingDownload.blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = downloadName || pendingDownload.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setShowDownloadModal(false);
    setPendingDownload(null);
    setDownloadName("");
  };

  const processSplit = async () => {
    if (!file) {
      alert("Pehle ek PDF select karo.");
      return;
    }
    if (!pdfLibLoaded || !window.PDFLib) {
      alert("PDF library abhi load ho rahi hai. Thoda wait karke dobara try karo.");
      return;
    }

    const fromPage = parseInt(splitPages.from) || 1;
    const toPage = parseInt(splitPages.to) || fromPage;

    if (fromPage < 1 || toPage < fromPage) {
      alert("Valid page range daalo (e.g. 1 to 3).");
      return;
    }

    setProcessing(true);
    setResult(null);

    try {
      const { PDFDocument } = window.PDFLib;
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await PDFDocument.load(arrayBuffer);
      const totalPages = pdf.getPageCount();

      const startIdx = Math.max(0, fromPage - 1);
      const endIdx = Math.min(totalPages - 1, toPage - 1);

      const newPdf = await PDFDocument.create();
      const indices = [];
      for (let i = startIdx; i <= endIdx; i++) indices.push(i);

      const copiedPages = await newPdf.copyPages(pdf, indices);
      copiedPages.forEach((p) => newPdf.addPage(p));

      const pdfBytes = await newPdf.save();
      const blob = new Blob([pdfBytes], { type: "application/pdf" });

      setResult({
        message: `PDF split: Pages ${startIdx + 1} to ${endIdx + 1} extracted`,
        files: [
          {
            name: `split_pages_${startIdx + 1}-${endIdx + 1}.pdf`,
            size: blob.size,
            blob,
          },
        ],
      });
    } catch (err) {
      console.error("Split error:", err);
      alert("PDF split mein error aaya. Console check karo.");
    }

    setProcessing(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={goHome}
        className="mb-6 text-indigo-600 hover:text-indigo-800 flex items-center font-medium"
      >
        ← Back to Tools
      </button>

      <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Split PDF</h2>
        <p className="text-gray-600">
          Extract specific page range from a PDF file.
        </p>
      </div>

      {/* Page Range Selector */}
      {file && (
        <div className="mb-4 p-4 bg-indigo-50 rounded-lg">
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Select Page Range to Split
          </label>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-gray-600 mb-1">
                From Page
              </label>
              <input
                type="number"
                min="1"
                value={splitPages.from}
                onChange={(e) =>
                  setSplitPages((prev) => ({
                    ...prev,
                    from: e.target.value,
                  }))
                }
                placeholder="1"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">To Page</label>
              <input
                type="number"
                min="1"
                value={splitPages.to}
                onChange={(e) =>
                  setSplitPages((prev) => ({
                    ...prev,
                    to: e.target.value,
                  }))
                }
                placeholder="1"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>
        </div>
      )}

      <UploadArea
        accept=".pdf"
        multiple={false}
        onFileSelect={handleFileSelect}
        onDrop={handleDrop}
      />

      {file && (
        <>
          <FileList
            files={[file]}
            isMergeTool={false}
            onRemove={handleRemove}
          />
          <ProcessButton onClick={processSplit} processing={processing} />
        </>
      )}

      {result && (
        <div className="mt-6 bg-green-50 border-2 border-green-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <Check className="text-green-600 mr-2" size={24} />
            <h3 className="text-lg font-semibold text-green-800">
              {result.message}
            </h3>
          </div>

          {result.files.map((file, i) => (
            <div
              key={i}
              className="flex items-center justify-between bg-white p-3 rounded-lg mb-2"
            >
              <div>
                <div className="text-gray-800">{file.name}</div>
                <div className="text-sm text-gray-500">
                  {(file.size / 1024).toFixed(1)} KB
                </div>
              </div>
              <button
                onClick={() => triggerDownload(file.blob, file.name)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Download
              </button>
            </div>
          ))}
        </div>
      )}

      <DownloadModal
        show={showDownloadModal}
        fileName={downloadName}
        setFileName={setDownloadName}
        onCancel={() => {
          setShowDownloadModal(false);
          setPendingDownload(null);
          setDownloadName("");
        }}
        onConfirm={confirmDownload}
      />
    </div>
  );
};

export default SplitPDF;
