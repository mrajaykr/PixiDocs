import React, { useState } from "react";
import UploadArea from "../../components/UploadArea";
import FileList from "../../components/FileList";
import ProcessButton from "../../components/ProcessButton";
import DownloadModal from "../../components/DownloadModal";
import { Check } from "lucide-react";

const EnhancePDF = ({ goHome }) => {
  const [files, setFiles] = useState([]);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);

  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [downloadName, setDownloadName] = useState("");
  const [pendingDownload, setPendingDownload] = useState(null);

  const handleFileSelect = (e) => {
    const selected = Array.from(e.target.files || []);
    setFiles(selected);
    setResult(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer.files || []);
    setFiles(dropped);
    setResult(null);
  };

  const handleRemove = (index) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const triggerDownload = (blob, name) => {
    setPendingDownload({ blob, name });
    setDownloadName(name);
    setShowDownloadModal(true);
  };

  const confirmDownload = () => {
    if (!pendingDownload) return;

    const url = URL.createObjectURL(pendingDownload.blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = downloadName || pendingDownload.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setShowDownloadModal(false);
    setPendingDownload(null);
    setDownloadName("");
  };

  const processEnhance = async () => {
    if (!files.length) {
      alert("Pehle PDF files select karo.");
      return;
    }

    setProcessing(true);
    setResult(null);

    try {
      // Purely simulated "AI enhancement"
      await new Promise((r) => setTimeout(r, 1500));

      const enhanced = files.map((f) => ({
        name: `enhanced_${f.name}`,
        size: Math.floor(f.size * 1.15),
        originalSize: f.size,
        blob: f,
      }));

      setResult({
        message: `Files enhanced using AI (simulated) — ${files.length} file${
          files.length > 1 ? "s" : ""
        }`,
        files: enhanced,
      });
    } catch (err) {
      console.error("Enhance error:", err);
      alert("AI enhance mein error aaya.");
    }

    setProcessing(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={goHome}
        className="mb-6 text-indigo-600 hover:text-indigo-800 flex items-center font-medium"
      >
        ← Back to Tools
      </button>

      <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">AI Enhance PDF</h2>
        <p className="text-gray-600">
          Simulated AI enhancement (quality/clarity meta only). Real AI models
          ke liye backend chahiye.
        </p>
      </div>

      <UploadArea
        accept=".pdf"
        multiple={true}
        onFileSelect={handleFileSelect}
        onDrop={handleDrop}
      />

      {files.length > 0 && (
        <>
          <FileList
            files={files}
            isMergeTool={false}
            onRemove={handleRemove}
          />
          <ProcessButton onClick={processEnhance} processing={processing} />
        </>
      )}

      {result && (
        <div className="mt-6 bg-green-50 border-2 border-green-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <Check className="text-green-600 mr-2" size={24} />
            <h3 className="text-lg font-semibold text-green-800">
              {result.message}
            </h3>
          </div>

          {result.files.map((file, i) => (
            <div
              key={i}
              className="flex items-center justify-between bg-white p-3 rounded-lg mb-2"
            >
              <div>
                <div className="text-gray-800">{file.name}</div>
                <div className="text-sm text-gray-500">
                  {(file.size / 1024).toFixed(1)} KB{" "}
                  {file.originalSize && (
                    <span className="ml-2 text-green-600 font-medium">
                      (+{(
                        (file.size - file.originalSize) /
                        1024
                      ).toFixed(1)}{" "}
                      KB enhanced)
                    </span>
                  )}
                </div>
              </div>
              <button
                onClick={() => triggerDownload(file.blob, file.name)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Download
              </button>
            </div>
          ))}

          <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              <strong>Note:</strong> Ye frontend-only simulation hai. Real AI
              enhancement ke liye server-side model integrate karna padega.
            </p>
          </div>
        </div>
      )}

      <DownloadModal
        show={showDownloadModal}
        fileName={downloadName}
        setFileName={setDownloadName}
        onCancel={() => {
          setShowDownloadModal(false);
          setPendingDownload(null);
          setDownloadName("");
        }}
        onConfirm={confirmDownload}
      />
    </div>
  );
};

export default EnhancePDF;
