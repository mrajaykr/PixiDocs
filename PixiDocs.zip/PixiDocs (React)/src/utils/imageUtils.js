// LOAD IMAGE (returns promise of HTMLImageElement)
export const loadImage = (file) =>
  new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });

// MERGE IMAGES
export const mergeImages = async (files, direction = "horizontal") => {
  const images = await Promise.all(files.map(loadImage));

  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");

  if (direction === "horizontal") {
    canvas.width = images.reduce((sum, img) => sum + img.width, 0);
    canvas.height = Math.max(...images.map((img) => img.height));

    let x = 0;
    images.forEach((img) => {
      ctx.drawImage(img, x, 0);
      x += img.width;
    });
  } else {
    canvas.width = Math.max(...images.map((img) => img.width));
    canvas.height = images.reduce((sum, img) => sum + img.height, 0);

    let y = 0;
    images.forEach((img) => {
      ctx.drawImage(img, 0, y);
      y += img.height;
    });
  }

  return new Promise((resolve) =>
    canvas.toBlob((blob) => resolve(blob), "image/png")
  );
};

// RESIZE IMAGE
export const resizeImage = (file, width, height) =>
  new Promise(async (resolve) => {
    const img = await loadImage(file);
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0, width, height);

    canvas.toBlob((blob) => {
      resolve({
        name: `resized_${file.name}`,
        size: blob.size,
        blob,
      });
    }, "image/png");
  });

// COMPRESS IMAGE
export const compressImage = (file, quality = 0.7) =>
  new Promise(async (resolve) => {
    const img = await loadImage(file);
    const canvas = document.createElement("canvas");
    canvas.width = img.width;
    canvas.height = img.height;

    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);

    canvas.toBlob(
      (blob) => {
        resolve({
          name: `compressed_${file.name}`,
          size: blob.size,
          blob,
        });
      },
      "image/jpeg",
      quality
    );
  });

// SIMULATED AI-ENHANCE
export const enhanceImage = async (file) => {
  await new Promise((res) => setTimeout(res, 800)); // fake delay

  return {
    name: `enhanced_${file.name}`,
    size: Math.floor(file.size * 1.2),
    originalSize: file.size,
    blob: file,
  };
};
