import { loadPdfLib } from "./loadPdfLib";

export const mergePDFs = async (files) => {
  const { PDFDocument } = await loadPdfLib();

  const mergedPdf = await PDFDocument.create();

  for (const file of files) {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await PDFDocument.load(arrayBuffer);

    const pages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
    pages.forEach((p) => mergedPdf.addPage(p));
  }

  const bytes = await mergedPdf.save();
  return new Blob([bytes], { type: "application/pdf" });
};

export const splitPDF = async (file, fromPage, toPage) => {
  const { PDFDocument } = await loadPdfLib();

  const data = await file.arrayBuffer();
  const pdf = await PDFDocument.load(data);

  const total = pdf.getPageCount();
  const start = Math.max(0, fromPage - 1);
  const end = Math.min(total - 1, toPage - 1);

  const newPdf = await PDFDocument.create();
  const pages = await newPdf.copyPages(pdf, [...Array(end - start + 1).keys()].map(i => i + start));

  pages.forEach((p) => newPdf.addPage(p));

  const outputBytes = await newPdf.save();
  return new Blob([outputBytes], { type: "application/pdf" });
};
