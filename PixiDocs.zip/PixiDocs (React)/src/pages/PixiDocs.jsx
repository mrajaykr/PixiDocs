import React, { useState, useRef } from "react";
import {
  Upload,
  FileText,
  Image,
  Wand2,
  Scissors,
  Merge,
  Download,
  Grid,
  Layout,
  X,
  Check,
  Loader2,
  GripVertical,
  ArrowUp,
  ArrowDown,
  Plus,
} from "lucide-react";

import { mergePDFs, splitPDF } from "../utils/pdfUtils";
import {
  mergeImages,
  resizeImage,
  compressImage,
  enhanceImage,
} from "../utils/imageUtils";
import { reorderFiles, formatFileSize } from "../utils/fileHelpers";
import { downloadBlob } from "../utils/download";

const PixiDocs = () => {
  const [activeTab, setActiveTab] = useState("home");
  const [files, setFiles] = useState([]);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);

  const [mergeDirection, setMergeDirection] = useState("horizontal");
  const [splitPages, setSplitPages] = useState({ from: "", to: "" });

  const [resizeOptions, setResizeOptions] = useState({
    width: 800,
    height: 600,
  });

  const [dragIndex, setDragIndex] = useState(null);
  const fileInput = useRef();
  const fileInputMore = useRef();

  const tools = [
    { id: "pdf-merge", name: "Merge PDF", icon: Merge, category: "pdf", accept: ".pdf" },
    { id: "pdf-split", name: "Split PDF", icon: Scissors, category: "pdf", accept: ".pdf" },
    { id: "img-merge", name: "Merge Images", icon: Layout, category: "image", accept: "image/*" },
    { id: "img-resize", name: "Resize Image", icon: Grid, category: "image", accept: "image/*" },
    { id: "img-compress", name: "Compress Image", icon: Image, category: "image", accept: "image/*" },
    { id: "img-enhance", name: "AI Enhance Image", icon: Wand2, category: "image", accept: "image/*" },
    { id: "pdf-enhance", name: "AI Enhance PDF", icon: Wand2, category: "pdf", accept: ".pdf" },
  ];

  const currentTool = tools.find((t) => t.id === activeTab);

  const isMergeTool = ["pdf-merge", "img-merge"].includes(activeTab);

  const handleFileSelect = (e) => {
    const newFiles = Array.from(e.target.files);
    setFiles(newFiles);
    setResult(null);
  };

  const addMoreFiles = (e) => {
    const newFiles = Array.from(e.target.files);
    setFiles([...files, ...newFiles]);
  };

  const onDrop = (e) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer.files);
    setFiles(dropped);
  };

  const removeFile = (i) => setFiles(files.filter((_, idx) => idx !== i));

  const handleDragStart = (i) => setDragIndex(i);

  const handleDragOver = (e, i) => {
    e.preventDefault();
    setFiles((prev) => reorderFiles(prev, dragIndex, i));
    setDragIndex(i);
  };

  const processFiles = async () => {
    if (!files.length) return;
    setProcessing(true);
    setResult(null);

    try {
      let output = null;

      switch (activeTab) {
        case "pdf-merge":
          output = await mergePDFs(files);
          setResult({
            message: `Merged ${files.length} PDFs`,
            files: [{ name: "merged.pdf", blob: output, size: output.size }],
          });
          break;

        case "pdf-split":
          const { from, to } = splitPages;
          output = await splitPDF(files[0], parseInt(from), parseInt(to));
          setResult({
            message: `Split pages ${from} - ${to}`,
            files: [{ name: `split_${from}-${to}.pdf`, blob: output, size: output.size }],
          });
          break;

        case "img-merge":
          output = await mergeImages(files, mergeDirection);
          setResult({
            message: `Merged ${files.length} images`,
            files: [{ name: `merged_${mergeDirection}.png`, blob: output, size: output.size }],
          });
          break;

        case "img-resize":
          const resized = await Promise.all(
            files.map((f) => resizeImage(f, resizeOptions.width, resizeOptions.height))
          );
          setResult({
            message: `Images resized to ${resizeOptions.width}×${resizeOptions.height}`,
            files: resized,
          });
          break;

        case "img-compress":
          const compressed = await Promise.all(files.map((f) => compressImage(f, 0.7)));
          setResult({
            message: `Images compressed`,
            files: compressed,
          });
          break;

        case "img-enhance":
        case "pdf-enhance":
          const enhanced = await Promise.all(files.map(enhanceImage));
          setResult({
            message: `AI enhanced ${files.length} file(s)`,
            files: enhanced,
          });
          break;

        default:
          break;
      }
    } catch (err) {
      alert("Error: " + err.message);
    }

    setProcessing(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* HEADER */}
      <header className="bg-white px-6 py-4 shadow flex justify-between items-center">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <FileText size={28} className="text-indigo-600" /> PixiDocs
        </h1>

        {activeTab !== "home" && (
          <button
            className="text-indigo-600 font-semibold"
            onClick={() => {
              setActiveTab("home");
              setFiles([]);
              setResult(null);
            }}
          >
            ← Back
          </button>
        )}
      </header>

      {/* HOME PAGE */}
      {activeTab === "home" ? (
        <div className="max-w-6xl mx-auto p-8">
          <h2 className="text-3xl font-bold mb-6">All Your File Tools</h2>

          <div className="grid md:grid-cols-3 gap-6">
            {tools.map((tool) => (
              <button
                key={tool.id}
                className="bg-white p-8 shadow rounded-xl hover:shadow-lg transition"
                onClick={() => setActiveTab(tool.id)}
              >
                <tool.icon className="text-indigo-600 mb-3" size={48} />
                <h3 className="font-semibold">{tool.name}</h3>
              </button>
            ))}
          </div>
        </div>
      ) : (
        /* TOOL PAGE */
        <div className="max-w-5xl mx-auto p-8">
          <h2 className="text-3xl font-bold mb-4">{currentTool.name}</h2>

          {/* Upload box */}
          <div
            className="p-10 border-2 border-dashed border-indigo-300 rounded-xl text-center bg-indigo-50"
            onClick={() => fileInput.current.click()}
            onDrop={onDrop}
            onDragOver={(e) => e.preventDefault()}
          >
            <Upload size={48} className="mx-auto mb-4 text-indigo-600" />
            <p className="font-semibold">Click or drag files here</p>

            <input
              ref={fileInput}
              type="file"
              className="hidden"
              accept={currentTool.accept}
              multiple={isMergeTool}
              onChange={handleFileSelect}
            />
          </div>

          {/* Files selected */}
          {files.length > 0 && (
            <div className="mt-8">
              <h3 className="font-semibold mb-2">Files ({files.length})</h3>

              {isMergeTool ? (
                <div className="grid md:grid-cols-3 gap-4">
                  {files.map((f, i) => (
                    <div
                      key={i}
                      draggable
                      onDragStart={() => handleDragStart(i)}
                      onDragOver={(e) => handleDragOver(e, i)}
                      className="bg-white p-4 shadow rounded-xl relative"
                    >
                      <GripVertical className="absolute left-2 top-2 text-gray-500" />

                      <p className="font-medium truncate">{f.name}</p>
                      <p className="text-sm text-gray-500">{formatFileSize(f.size)}</p>

                      <button
                        onClick={() => removeFile(i)}
                        className="absolute right-2 top-2 text-red-500"
                      >
                        <X size={18} />
                      </button>
                    </div>
                  ))}

                  {/* Add more */}
                  <div
                    className="bg-indigo-50 border-2 border-dashed border-indigo-300 p-4 rounded-xl flex flex-col justify-center items-center cursor-pointer"
                    onClick={() => fileInputMore.current.click()}
                  >
                    <Plus size={30} className="text-indigo-600" />
                    <p>Add more</p>

                    <input
                      ref={fileInputMore}
                      type="file"
                      className="hidden"
                      accept={currentTool.accept}
                      multiple
                      onChange={addMoreFiles}
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  {files.map((file, i) => (
                    <div
                      key={i}
                      className="bg-white p-3 shadow rounded-lg flex justify-between items-center"
                    >
                      <span>{file.name}</span>
                      <span className="text-sm">{formatFileSize(file.size)}</span>

                      <button
                        className="text-red-500"
                        onClick={() => removeFile(i)}
                      >
                        <X size={20} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Options depending on tool */}
              {activeTab === "img-merge" && (
                <div className="mt-6">
                  <label className="font-semibold">Merge Direction</label>
                  <div className="flex gap-4 mt-2">
                    <button
                      className={`px-4 py-2 rounded-lg ${
                        mergeDirection === "horizontal"
                          ? "bg-indigo-600 text-white"
                          : "bg-white border"
                      }`}
                      onClick={() => setMergeDirection("horizontal")}
                    >
                      Horizontal →
                    </button>

                    <button
                      className={`px-4 py-2 rounded-lg ${
                        mergeDirection === "vertical"
                          ? "bg-indigo-600 text-white"
                          : "bg-white border"
                      }`}
                      onClick={() => setMergeDirection("vertical")}
                    >
                      Vertical ↓
                    </button>
                  </div>
                </div>
              )}

              {activeTab === "pdf-split" && (
                <div className="mt-6 grid grid-cols-2 gap-4">
                  <input
                    type="number"
                    placeholder="From page"
                    className="border p-3 rounded-lg"
                    value={splitPages.from}
                    onChange={(e) =>
                      setSplitPages({ ...splitPages, from: e.target.value })
                    }
                  />
                  <input
                    type="number"
                    placeholder="To page"
                    className="border p-3 rounded-lg"
                    value={splitPages.to}
                    onChange={(e) =>
                      setSplitPages({ ...splitPages, to: e.target.value })
                    }
                  />
                </div>
              )}

              {/* Process button */}
              <button
                onClick={processFiles}
                className="mt-6 w-full bg-indigo-600 text-white p-4 rounded-xl text-lg font-semibold flex justify-center items-center"
                disabled={processing}
              >
                {processing ? <Loader2 className="animate-spin mr-2" /> : <Wand2 className="mr-2" />}
                {processing ? "Processing..." : "Process"}
              </button>

              {/* Results */}
              {result && (
                <div className="mt-8 bg-green-50 border border-green-300 p-6 rounded-xl">
                  <h4 className="font-bold text-green-700 flex items-center gap-2">
                    <Check /> {result.message}
                  </h4>

                  <div className="mt-4 space-y-3">
                    {result.files.map((f, i) => (
                      <div
                        key={i}
                        className="flex justify-between items-center bg-white p-3 shadow rounded-lg"
                      >
                        <div>
                          <p className="font-medium">{f.name}</p>
                          <p className="text-sm text-gray-600">{formatFileSize(f.size)}</p>
                        </div>

                        <button
                          className="bg-green-600 text-white px-4 py-2 rounded-lg"
                          onClick={() => downloadBlob(f.blob, f.name)}
                        >
                          <Download size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PixiDocs;
