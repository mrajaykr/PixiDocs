import React, { useState } from "react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import ToolCard from "./components/ToolCard";
import tools from "./constants/tools";

import MergePDF from "./tools/pdf/MergePDF";
import SplitPDF from "./tools/pdf/SplitPDF";
import CompressPDF from "./tools/pdf/CompressPDF";
import EnhancePDF from "./tools/pdf/EnhancePDF";

import MergeImage from "./tools/image/MergeImage";
import ResizeImage from "./tools/image/ResizeImage";
import CompressImage from "./tools/image/CompressImage";
import EnhanceImage from "./tools/image/EnhanceImage";

const App = () => {
  const [activeTool, setActiveTool] = useState("home");

  const renderTool = () => {
    switch (activeTool) {
      case "pdf-merge": return <MergePDF goHome={() => setActiveTool("home")} />;
      case "pdf-split": return <SplitPDF goHome={() => setActiveTool("home")} />;
      case "pdf-compress": return <CompressPDF goHome={() => setActiveTool("home")} />;
      case "pdf-enhance": return <EnhancePDF goHome={() => setActiveTool("home")} />;
      
      case "img-merge": return <MergeImage goHome={() => setActiveTool("home")} />;
      case "img-resize": return <ResizeImage goHome={() => setActiveTool("home")} />;
      case "img-compress": return <CompressImage goHome={() => setActiveTool("home")} />;
      case "img-enhance": return <EnhanceImage goHome={() => setActiveTool("home")} />;
      
      default:
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 p-10">
            {tools.map(t => (
              <ToolCard key={t.id} tool={t} setActiveTool={setActiveTool} />
            ))}
          </div>
        );
    }
  };

  return (
    <>
      <Header />
      {renderTool()}
      <Footer />
    </>
  );
};

export default App;
